package tpv.productos;

import tpv.Producto;

public class Ingrediente extends Producto {
    public Ingrediente(String nombre, String descripcion, double precio, double cantidad) {
        super(nombre, descripcion, precio, cantidad);
    }
}
